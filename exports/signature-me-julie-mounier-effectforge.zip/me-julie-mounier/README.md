# 🎨 Signature Email Animée — Me. Julie MOUNIER
> Générée par **EffectForge AI** · 10 avril 2026

---

## 👤 Identité

| Champ | Valeur |
|-------|--------|
| **Nom** | Me. Julie MOUNIER |
| **Titre** | Avocat |
| **Entreprise** | Cabinet Julie MOUNIER |
| **Secteur** | services_pro |
| **Email** | contact@cabinetmounier.com |
| **Téléphone** | 06 71 91 84 02 |
| **Site web** | www.cabinetmounier.com/ |
| **ID Signature** | `1cdf6315-0c7d-4932-8ab9-3902e3012356` |

---

## 📦 Contenu du package

| Fichier | Description | Client recommandé |
|---------|-------------|-------------------|
| `PREVIEW — Ouvrez ce fichier.html` | **Commencez ici** — aperçu interactif de votre signature | Navigateur |
| `signature-gmail.html` | Version CSS animée | Gmail, Outlook.com, Yahoo |
| `signature-outlook.htm` | Version MSO compatible, table HTML | Outlook 2016–2024 (Windows) |
| `signature-apple-mail.html` | Version CSS webkit animée | Apple Mail, iOS Mail |
| `signature-universelle.html` | Version hybride SVG/CSS | Thunderbird, autres |
| `signature-animee.svg` | SVG animé standalone | Intégration web, embed |
| `signature-animee.gif` | GIF animé universel | Clients sans CSS |
| `signature-statique.png` | Image PNG haute résolution | Fallback universel |
| `GUIDE_INSTALLATION.html` | Guide pas-à-pas interactif | — |
| `palette-de-marque.html` | Charte colorimétrique officielle | — |
| `metadata.json` | Configuration technique complète | Développeurs |

---

## 🚀 Installation rapide

### Gmail
1. Ouvrir **Gmail** → ⚙️ Paramètres → *Voir tous les paramètres*
2. Onglet **Général** → section **Signature** → *Créer une signature*
3. Cliquer sur l'icône **`< >`** (HTML) dans l'éditeur de signature
4. Copier-coller le contenu de `signature-gmail.html`
5. **Enregistrer les modifications** en bas de page

### Outlook 2016–2024
1. **Fichier** → **Options** → **Courrier** → **Signatures**
2. Cliquer **Nouveau** → donner un nom
3. Dans l'onglet **Message**, cliquer sur l'icône HTML
4. Coller le contenu de `signature-outlook.htm`
5. **OK** pour enregistrer

### Apple Mail
1. **Mail** → **Préférences** → **Signatures**
2. Sélectionner votre compte → cliquer **+**
3. Désactiver *"Toujours utiliser la police par défaut"*
4. Glisser `signature-apple-mail.html` dans la zone de signature
5. Redémarrer Apple Mail

> 💡 **Conseil** : Ouvrez d'abord `GUIDE_INSTALLATION.html` pour un guide visuel complet avec captures d'écran.

---

## 🎨 Palette de marque

- **Fond principal** : `#1A1035`
- **Couleur d'accent** : `#7C3AED`
- **Texte clair** : `#EDE9FE`



---

## ⚠️ Compatibilité

| Client | Animation | Format recommandé |
|--------|-----------|-------------------|
| Gmail | ✅ CSS animé | signature-gmail.html |
| Outlook 2016–2024 | 🖼 GIF (1er frame statique possible) | signature-outlook.htm |
| Apple Mail | ✅ CSS animé | signature-apple-mail.html |
| iOS Mail | ✅ SVG animé | signature-universelle.html |
| Outlook.com | ✅ CSS animé | signature-gmail.html |
| Thunderbird | ✅ CSS animé | signature-apple-mail.html |
| Yahoo Mail | 🖼 GIF | signature-gmail.html |

---

## 📞 Support

Ce package a été généré par **EffectForge AI — God Tier Engine v3.0**.
Pour toute assistance, consultez le `GUIDE_INSTALLATION.html` inclus.

---

*© EffectForge AI · Me. Julie MOUNIER · Cabinet Julie MOUNIER · 10 avril 2026*
